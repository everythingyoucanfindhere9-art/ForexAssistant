# Keep Anthropic API models
-keep class com.forexassistant.api.** { *; }
-keep class com.google.gson.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
