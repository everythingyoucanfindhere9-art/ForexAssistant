package com.forexassistant.ui

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.forexassistant.R
import com.forexassistant.utils.PrefsManager

class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        prefs = PrefsManager(this)
        setupUI()
    }

    private fun setupUI() {
        val etApiKey = findViewById<EditText>(R.id.etApiKey)
        val btnSave = findViewById<Button>(R.id.btnSaveSettings)
        val tvApiInfo = findViewById<TextView>(R.id.tvApiInfo)
        val switchAutoAnalyze = findViewById<Switch>(R.id.switchAutoAnalyze)
        val switchVibrate = findViewById<Switch>(R.id.switchVibrate)

        etApiKey.setText(prefs.apiKey)
        switchAutoAnalyze.isChecked = prefs.autoAnalyze
        switchVibrate.isChecked = prefs.vibrateOnAlert

        tvApiInfo.text = """
How to get your FREE Gemini API key:
1. Go to aistudio.google.com
2. Sign in with your Google account
3. Click "Get API Key" (top left)
4. Click "Create API Key"
5. Copy the key (starts with AIza...)
6. Paste it above and save

FREE TIER limits (more than enough):
• 1,500 requests per day FREE
• 1 million tokens per minute
• No credit card needed!

Model: Gemini 1.5 Flash
""".trimIndent()

        btnSave.setOnClickListener {
            val key = etApiKey.text.toString().trim()
            if (key.isEmpty()) {
                Toast.makeText(this, "Please enter your API key", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            prefs.apiKey = key
            prefs.autoAnalyze = switchAutoAnalyze.isChecked
            prefs.vibrateOnAlert = switchVibrate.isChecked
            Toast.makeText(this, "✅ Settings saved!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
