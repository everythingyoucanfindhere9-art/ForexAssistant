package com.forexassistant.utils

import android.content.Context
import android.content.SharedPreferences

class PrefsManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("forex_assistant_prefs", Context.MODE_PRIVATE)

    companion object {
        const val KEY_API_KEY = "api_key"
        const val KEY_OVERLAY_OPACITY = "overlay_opacity"
        const val KEY_OVERLAY_SIZE = "overlay_size"
        const val KEY_AUTO_ANALYZE = "auto_analyze"
        const val KEY_VIBRATE_ON_ALERT = "vibrate_on_alert"
    }

    var apiKey: String
        get() = prefs.getString(KEY_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_API_KEY, value).apply()

    var overlayOpacity: Float
        get() = prefs.getFloat(KEY_OVERLAY_OPACITY, 0.9f)
        set(value) = prefs.edit().putFloat(KEY_OVERLAY_OPACITY, value).apply()

    var overlaySize: Int
        get() = prefs.getInt(KEY_OVERLAY_SIZE, 1) // 0=small, 1=medium, 2=large
        set(value) = prefs.edit().putInt(KEY_OVERLAY_SIZE, value).apply()

    var autoAnalyze: Boolean
        get() = prefs.getBoolean(KEY_AUTO_ANALYZE, false)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_ANALYZE, value).apply()

    var vibrateOnAlert: Boolean
        get() = prefs.getBoolean(KEY_VIBRATE_ON_ALERT, true)
        set(value) = prefs.edit().putBoolean(KEY_VIBRATE_ON_ALERT, value).apply()

    fun hasApiKey(): Boolean = apiKey.isNotBlank()
}
