package com.forexassistant.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.app.NotificationCompat
import com.forexassistant.R
import com.forexassistant.api.ApiResult
import com.forexassistant.api.ClaudeApiService
import com.forexassistant.utils.PrefsManager
import kotlinx.coroutines.*

class FloatingService : Service() {

    private lateinit var windowManager: WindowManager
    private var floatingBubbleView: View? = null
    private var floatingPanelView: View? = null
    private var screenCaptureService: ScreenCaptureService? = null

    private lateinit var prefs: PrefsManager
    private lateinit var claudeApi: ClaudeApiService
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var isPanelVisible = false
    private var isAnalyzing = false

    companion object {
        const val CHANNEL_ID = "floating_service_channel"
        const val NOTIFICATION_ID = 1
        const val ACTION_START = "START_FLOATING"
        const val ACTION_STOP = "STOP_FLOATING"
        var captureServiceInstance: ScreenCaptureService? = null
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = PrefsManager(this)
        claudeApi = ClaudeApiService(prefs.apiKey)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForeground(NOTIFICATION_ID, buildNotification())
                showFloatingBubble()
            }
            ACTION_STOP -> {
                removeFloatingViews()
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun showFloatingBubble() {
        if (floatingBubbleView != null) return
        val inflater = LayoutInflater.from(this)
        floatingBubbleView = inflater.inflate(R.layout.floating_bubble, null)

        val bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50; y = 200
        }

        setupBubbleDrag(floatingBubbleView!!, bubbleParams)
        windowManager.addView(floatingBubbleView, bubbleParams)

        floatingBubbleView?.findViewById<View>(R.id.bubbleIcon)?.setOnClickListener {
            togglePanel()
        }
    }

    private fun togglePanel() {
        if (isPanelVisible) hidePanel() else showPanel()
    }

    private fun showPanel() {
        if (floatingPanelView != null) return
        val inflater = LayoutInflater.from(this)
        floatingPanelView = inflater.inflate(R.layout.floating_panel, null)

        val panelParams = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.92).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 80
        }

        windowManager.addView(floatingPanelView, panelParams)
        isPanelVisible = true
        setupPanelInteractions(floatingPanelView!!)
    }

    private fun hidePanel() {
        floatingPanelView?.let {
            windowManager.removeView(it)
            floatingPanelView = null
        }
        isPanelVisible = false
    }

    private fun setupPanelInteractions(panel: View) {
        val tvAnalysis = panel.findViewById<TextView>(R.id.tvAnalysis)
        val etQuestion = panel.findViewById<EditText>(R.id.etQuestion)
        val btnAnalyze = panel.findViewById<Button>(R.id.btnAnalyzeChart)
        val btnAsk = panel.findViewById<Button>(R.id.btnAskQuestion)
        val btnClose = panel.findViewById<ImageButton>(R.id.btnClosePanel)
        val progressBar = panel.findViewById<ProgressBar>(R.id.progressBar)
        val statusDot = panel.findViewById<View>(R.id.statusDot)

        btnClose.setOnClickListener { hidePanel() }

        btnAnalyze.setOnClickListener {
            if (isAnalyzing) return@setOnClickListener
            val question = etQuestion.text.toString()
            val screenshot = captureCurrentScreen()
            if (screenshot == null) {
                tvAnalysis.text = "⚠️ Could not capture screen.\nMake sure screen capture permission was granted in Settings."
                return@setOnClickListener
            }
            analyzeChart(screenshot, question, tvAnalysis, progressBar, statusDot, btnAnalyze, btnAsk)
        }

        btnAsk.setOnClickListener {
            val question = etQuestion.text.toString().trim()
            if (question.isEmpty()) {
                tvAnalysis.text = "Please type your forex question first."
                return@setOnClickListener
            }
            if (isAnalyzing) return@setOnClickListener
            askQuestion(question, tvAnalysis, progressBar, statusDot, btnAnalyze, btnAsk)
        }
    }

    private fun captureCurrentScreen(): Bitmap? {
        return try {
            captureServiceInstance?.captureScreen()
        } catch (e: Exception) {
            null
        }
    }

    private fun analyzeChart(
        screenshot: Bitmap,
        question: String,
        tvAnalysis: TextView,
        progressBar: ProgressBar,
        statusDot: View,
        vararg buttons: View
    ) {
        if (prefs.apiKey.isEmpty()) {
            tvAnalysis.text = "⚠️ No API key set.\nPlease open Forex Assistant app and go to Settings to add your Anthropic API key."
            return
        }
        isAnalyzing = true
        progressBar.visibility = View.VISIBLE
        statusDot.setBackgroundResource(R.drawable.dot_analyzing)
        buttons.forEach { it.isEnabled = false }
        tvAnalysis.text = "🔍 Analyzing your chart with AI...\nThis takes 5-15 seconds."
        claudeApi.updateApiKey(prefs.apiKey)

        serviceScope.launch {
            val result = claudeApi.analyzeChart(screenshot, question)
            progressBar.visibility = View.GONE
            statusDot.setBackgroundResource(R.drawable.dot_ready)
            buttons.forEach { it.isEnabled = true }
            isAnalyzing = false
            when (result) {
                is ApiResult.Success -> tvAnalysis.text = result.text
                is ApiResult.Error -> tvAnalysis.text = "❌ Error: ${result.message}"
            }
        }
    }

    private fun askQuestion(
        question: String,
        tvAnalysis: TextView,
        progressBar: ProgressBar,
        statusDot: View,
        vararg buttons: View
    ) {
        if (prefs.apiKey.isEmpty()) {
            tvAnalysis.text = "⚠️ No API key set. Please open app Settings."
            return
        }
        isAnalyzing = true
        progressBar.visibility = View.VISIBLE
        statusDot.setBackgroundResource(R.drawable.dot_analyzing)
        buttons.forEach { it.isEnabled = false }
        tvAnalysis.text = "💭 Getting answer..."
        claudeApi.updateApiKey(prefs.apiKey)

        serviceScope.launch {
            val result = claudeApi.askQuestion(question)
            progressBar.visibility = View.GONE
            statusDot.setBackgroundResource(R.drawable.dot_ready)
            buttons.forEach { it.isEnabled = true }
            isAnalyzing = false
            when (result) {
                is ApiResult.Success -> tvAnalysis.text = result.text
                is ApiResult.Error -> tvAnalysis.text = "❌ Error: ${result.message}"
            }
        }
    }

    private fun setupBubbleDrag(view: View, params: WindowManager.LayoutParams) {
        var lastX = 0; var lastY = 0; var startX = 0; var startY = 0
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = event.rawX.toInt(); lastY = event.rawY.toInt()
                    startX = params.x; startY = params.y
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX.toInt() - lastX
                    val dy = event.rawY.toInt() - lastY
                    params.x = startX + dx; params.y = startY + dy
                    windowManager.updateViewLayout(view, params)
                    true
                }
                else -> false
            }
        }
    }

    private fun removeFloatingViews() {
        hidePanel()
        floatingBubbleView?.let {
            windowManager.removeView(it)
            floatingBubbleView = null
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Forex Assistant",
            NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Floating forex trading assistant" }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, FloatingService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("📈 Forex Assistant Active")
            .setContentText("Tap bubble on screen to open analysis panel")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPending)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        serviceScope.cancel()
        removeFloatingViews()
        super.onDestroy()
    }
}
