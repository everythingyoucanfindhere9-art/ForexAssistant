package com.forexassistant.ui

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.forexassistant.R
import com.forexassistant.service.FloatingService
import com.forexassistant.service.ScreenCaptureService
import com.forexassistant.utils.PrefsManager

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsManager
    private val REQUEST_OVERLAY = 100
    private val REQUEST_SCREEN_CAPTURE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = PrefsManager(this)
        setupUI()
    }

    private fun setupUI() {
        val btnLaunch = findViewById<Button>(R.id.btnLaunchFloating)
        val btnStop = findViewById<Button>(R.id.btnStopFloating)
        val btnSettings = findViewById<Button>(R.id.btnSettings)
        val tvStatus = findViewById<TextView>(R.id.tvStatus)
        val tvApiStatus = findViewById<TextView>(R.id.tvApiStatus)

        tvApiStatus.text = if (prefs.hasApiKey()) "✅ API Key configured" else "⚠️ No API key — go to Settings"

        btnLaunch.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                requestOverlayPermission()
            } else {
                requestScreenCapture()
            }
        }

        btnStop.setOnClickListener {
            stopFloatingService()
            tvStatus.text = "Status: Stopped"
        }

        btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun requestOverlayPermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivityForResult(intent, REQUEST_OVERLAY)
    }

    private fun requestScreenCapture() {
        val projectionManager = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val tvStatus = findViewById<TextView>(R.id.tvStatus)

        when (requestCode) {
            REQUEST_OVERLAY -> {
                if (Settings.canDrawOverlays(this)) {
                    requestScreenCapture()
                } else {
                    tvStatus.text = "⚠️ Overlay permission denied. Please grant it to use floating assistant."
                }
            }
            REQUEST_SCREEN_CAPTURE -> {
                if (resultCode == Activity.RESULT_OK && data != null) {
                    // Start screen capture service
                    val captureIntent = Intent(this, ScreenCaptureService::class.java).apply {
                        action = ScreenCaptureService.ACTION_START
                        putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                        putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                    }
                    startForegroundService(captureIntent)

                    // Start floating overlay service
                    val floatIntent = Intent(this, FloatingService::class.java).apply {
                        action = FloatingService.ACTION_START
                    }
                    startForegroundService(floatIntent)
                    tvStatus.text = "✅ Floating assistant is active!\nYou can now switch to MT5."
                    // Minimize this app
                    moveTaskToBack(true)
                } else {
                    tvStatus.text = "⚠️ Screen capture permission denied.\nChart analysis will be limited."
                    // Still start floating (without screen capture)
                    val floatIntent = Intent(this, FloatingService::class.java).apply {
                        action = FloatingService.ACTION_START
                    }
                    startForegroundService(floatIntent)
                    moveTaskToBack(true)
                }
            }
        }
    }

    private fun stopFloatingService() {
        stopService(Intent(this, FloatingService::class.java))
        stopService(Intent(this, ScreenCaptureService::class.java))
    }

    override fun onResume() {
        super.onResume()
        val tvApiStatus = findViewById<TextView>(R.id.tvApiStatus)
        tvApiStatus.text = if (prefs.hasApiKey()) "✅ API Key configured" else "⚠️ No API key — go to Settings"
    }
}
