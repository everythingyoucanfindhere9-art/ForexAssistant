package com.forexassistant.api

import android.graphics.Bitmap
import android.util.Base64
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

// Gemini API request/response models
data class GeminiPart(
    val text: String? = null,
    @SerializedName("inline_data") val inlineData: GeminiInlineData? = null
)

data class GeminiInlineData(
    @SerializedName("mime_type") val mimeType: String,
    val data: String
)

data class GeminiContent(
    val role: String = "user",
    val parts: List<GeminiPart>
)

data class GeminiSystemInstruction(
    val parts: List<GeminiPart>
)

data class GeminiGenerationConfig(
    @SerializedName("maxOutputTokens") val maxOutputTokens: Int = 1024,
    val temperature: Double = 0.4
)

data class GeminiRequest(
    @SerializedName("system_instruction") val systemInstruction: GeminiSystemInstruction,
    val contents: List<GeminiContent>,
    @SerializedName("generationConfig") val generationConfig: GeminiGenerationConfig = GeminiGenerationConfig()
)

data class GeminiResponse(
    val candidates: List<GeminiCandidate>?
)

data class GeminiCandidate(
    val content: GeminiContent?
)

sealed class ApiResult {
    data class Success(val text: String) : ApiResult()
    data class Error(val message: String) : ApiResult()
}

class ClaudeApiService(private var apiKey: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
    private val gson = Gson()

    // Model: gemini-1.5-flash — free tier: 1,500 requests/day, 1M tokens/min
    private val model = "gemini-1.5-flash"

    fun updateApiKey(key: String) { apiKey = key }

    private val systemPromptText = """
You are an expert Forex trading assistant specializing in Smart Money Concepts (SMC) and Price Action.
Your expertise includes: Order blocks, Fair Value Gaps (FVG), Breaker blocks, Market Structure (HH/HL/LH/LL),
Change of Character (CHoCH), Break of Structure (BOS), Liquidity grabs, ICT kill zones, OTE levels,
Supply/Demand zones, candlestick patterns, and risk management.

When analyzing a chart screenshot:
1. Identify the PAIR and TIMEFRAME if visible
2. Identify current market structure (bullish/bearish/ranging)
3. Note key levels: Order blocks, FVGs, significant highs/lows
4. Identify any CHoCH or BOS that has occurred
5. Look for liquidity pools above/below price
6. Give a clear BIAS (Bullish/Bearish/Neutral) with reasoning
7. Suggest a trade setup if one exists (entry zone, SL, TP1, TP2)
8. Be concise and actionable — the trader is live trading

Respond using these section headers exactly:
📊 STRUCTURE: [your analysis]
🎯 KEY LEVELS: [your analysis]
💡 BIAS: [Bullish/Bearish/Neutral + reason]
📈 SETUP: [entry, SL, TP or "No clear setup currently"]
⚠️ RISK NOTE: [brief risk reminder]
""".trimIndent()

    suspend fun analyzeChart(screenshot: Bitmap, userQuestion: String = ""): ApiResult =
        withContext(Dispatchers.IO) {
            try {
                val base64Image = bitmapToBase64(screenshot)
                val questionText = if (userQuestion.isNotBlank())
                    "Analyze this forex chart. Additional question: $userQuestion"
                else
                    "Analyze this forex chart and give me your full SMC/price action analysis."

                val request = GeminiRequest(
                    systemInstruction = GeminiSystemInstruction(listOf(GeminiPart(text = systemPromptText))),
                    contents = listOf(
                        GeminiContent(parts = listOf(
                            GeminiPart(inlineData = GeminiInlineData(mimeType = "image/jpeg", data = base64Image)),
                            GeminiPart(text = questionText)
                        ))
                    )
                )
                executeRequest(request)
            } catch (e: Exception) { ApiResult.Error("Error: ${e.message}") }
        }

    suspend fun askQuestion(question: String): ApiResult = withContext(Dispatchers.IO) {
        try {
            val request = GeminiRequest(
                systemInstruction = GeminiSystemInstruction(listOf(GeminiPart(text = systemPromptText))),
                contents = listOf(
                    GeminiContent(parts = listOf(GeminiPart(text = question)))
                )
            )
            executeRequest(request)
        } catch (e: Exception) { ApiResult.Error("Error: ${e.message}") }
    }

    private fun executeRequest(request: GeminiRequest): ApiResult {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
        val body = gson.toJson(request).toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url(url).post(body).build()
        val resp = client.newCall(req).execute()
        val respBody = resp.body?.string() ?: ""
        return if (resp.isSuccessful) {
            val data = gson.fromJson(respBody, GeminiResponse::class.java)
            val text = data.candidates
                ?.firstOrNull()?.content?.parts
                ?.firstOrNull { it.text != null }?.text
                ?: "No response from Gemini."
            ApiResult.Success(text)
        } else {
            ApiResult.Error("Gemini API Error ${resp.code}: $respBody")
        }
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val out = ByteArrayOutputStream()
        val max = 1568
        val scaled = if (bitmap.width > max || bitmap.height > max) {
            val scale = max.toFloat() / maxOf(bitmap.width, bitmap.height)
            Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).toInt(), (bitmap.height * scale).toInt(), true)
        } else bitmap
        scaled.compress(Bitmap.CompressFormat.JPEG, 85, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}
