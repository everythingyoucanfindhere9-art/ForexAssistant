# 📈 Forex Assistant — Build Guide (Gemini Edition — FREE)

## What This App Does
A floating Android overlay that sits on top of MT5 while you trade.
- Captures your screen automatically
- Sends chart to Google Gemini AI for analysis (FREE — 1,500/day)
- Gives you: Market Structure, Key Levels, Bias, Trade Setup
- You can also type any forex question

---

## Step 1: Get Your FREE Gemini API Key
1. Go to https://aistudio.google.com
2. Sign in with your Google account (Gmail)
3. Click "Get API Key" in the top-left
4. Click "Create API Key"
5. Copy the key (starts with `AIza...`)
6. **Save it — you'll paste it into the app Settings**

✅ FREE tier: 1,500 chart analyses per day — no credit card needed!

---

## Step 2: Install Android Studio
1. Download: https://developer.android.com/studio
2. Install (default options)
3. On first launch, let it download the Android SDK (~5-10 min)

---

## Step 3: Open the Project
1. Extract the ForexAssistant zip
2. Open Android Studio → Click "Open"
3. Navigate to the `ForexAssistant` folder → click OK
4. Wait for Gradle sync (first time: 3-5 min)

---

## Step 4: Connect Your Phone
1. Settings → About Phone → tap "Build Number" 7 times
2. Settings → Developer Options → enable "USB Debugging"
3. Plug phone into computer via USB
4. Tap "Allow" when prompted on phone

---

## Step 5: Build & Install
1. Select your phone in the device dropdown (top of Android Studio)
2. Click the green ▶ Play button
3. App installs on your phone automatically

---

## Step 6: First Time Setup
1. Open "Forex Assistant" on your phone
2. Tap "⚙️ Settings / API Key"
3. Paste your Gemini API key (AIza...)
4. Tap "Save Settings"

---

## Step 7: Launch & Trade
1. Tap "🚀 Launch Floating Assistant"
2. Grant "Display over other apps" when asked
3. Grant "Screen Capture" when asked
4. App minimizes — green 📈 bubble appears on screen
5. Open MT5 and trade normally
6. Tap the 📈 bubble anytime → opens analysis panel
7. Tap "📸 Analyze Chart" → AI analyzes your MT5 chart (~5-10 sec)

---

## Troubleshooting

**"Overlay permission denied"**
→ Settings → Apps → Forex Assistant → Display over other apps → Allow

**"API Error 400"**
→ Your API key may be wrong. Get a fresh one at aistudio.google.com

**"API Error 429"**
→ You've hit the daily free limit (1,500/day). Resets at midnight.

**App crashes**
→ Requires Android 8.0 (Oreo) or higher

---

## Free Tier Summary
| | Gemini 1.5 Flash (this app) |
|---|---|
| Daily free requests | 1,500 |
| Cost after that | ~$0.0001/request |
| Credit card needed? | No |
| Quality | Excellent for chart analysis |

